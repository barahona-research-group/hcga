#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 24 12:43:43 2019

@author: robert
"""

#%%

import numpy as np
import scipy as sc

data = sc.io.loadmat('qm7.mat')

P = data['P'] # splits for cross validation
R = data['R'] # cartesian coordinates
T = data['T'] # labels: atomization energies
X = data['X'] # inputs : coulomb matrices
Z = data['Z'] # atomic charge 

#%%
import networkx as nx
import pandas as pd


graph_labels = T.ravel()

graphs = []


for i in range(len(graph_labels)):
    G = nx.Graph(X[i,:,:])
    
    feats = pd.DataFrame(Z[i,:]).stack().groupby(level=0).agg(list).to_dict()
    nx.set_node_attributes(G, feats, 'feat')

    
    graphs.append(G)
    
#%%
import pickle

pickle.dump((graphs,graph_labels),open('qm7_graphs.pkl','wb'))    